from datetime import datetime
from app.database import create_tables, salvar_inspecao_db, listar_inspecoes
from fastapi import FastAPI, Request, Form
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

from app.database import create_tables, salvar_inspecao_db

app = FastAPI(title="Relatório de Motoristas")

app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")


@app.on_event("startup")
def startup():
    create_tables()


@app.get("/")
def login_page(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="login.html"
    )


@app.get("/menu")
def menu_page(request: Request, usuario: str = ""):
    return templates.TemplateResponse(
        request=request,
        name="menu.html",
        context={"usuario": usuario}
    )

@app.post("/inspecao")
def salvar_inspecao(
    request: Request,
    usuario: str = Form(...),
    farois: str = Form(...),
    lanternas: str = Form(...),
    pneus: str = Form(...),
    observacoes: str = Form("")
):
    data_hora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    salvar_inspecao_db(
        data_hora=data_hora,
        farois=farois,
        lanternas=lanternas,
        pneus=pneus,
        observacoes=observacoes
    )

    return templates.TemplateResponse(
        request=request,
        name="menu.html"
    )
@app.get("/historico")
def historico(request: Request):
    dados = listar_inspecoes()

    return templates.TemplateResponse(
        request=request,
        name="historico.html",
        context={"dados": dados}
    )