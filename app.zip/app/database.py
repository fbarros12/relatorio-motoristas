import sqlite3

DB_NAME = "relatorio_motoristas.db"


def salvar_inspecao_db(data_hora, usuario, farois, lanternas, pneus, observacoes):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO inspecoes (
            data_hora,
            usuario,
            farois,
            lanternas,
            pneus,
            observacoes
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, (data_hora, usuario, farois, lanternas, pneus, observacoes))

    conn.commit()
    conn.close()


def salvar_inspecao_db(data_hora, farois, lanternas, pneus, observacoes):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO inspecoes (
            data_hora,
            farois,
            lanternas,
            pneus,
            observacoes
        ) VALUES (?, ?, ?, ?, ?)
    """, (data_hora, farois, lanternas, pneus, observacoes))

    conn.commit()
    conn.close()

def listar_inspecoes():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM inspecoes ORDER BY data_hora DESC")
    dados = cursor.fetchall()

    conn.close()
    return dados